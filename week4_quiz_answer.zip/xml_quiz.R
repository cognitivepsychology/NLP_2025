# xml2 패키지 불러오기.
library(xml2)
library(tidyverse)

# xml_week2 폴더 밑에 하위 폴더 quiz 만들기.
dir.create("xml_week2/quiz")

# xml 파일 목록 불러온 뒤 파일 경로 생성하기.
xml_list <- list.files(path = "xml_week2/quiz", pattern = "sjml$", recursive = T)
xml_list.1 <- str_c("xml_week2/quiz/", xml_list)

# 여러 개의 XML 파일을 한꺼번에 불러와 티블로 만들기.
quiz_xml_result <- map_dfr(xml_list.1, ~{
  tryCatch( # 연속작업 실행 중 오류가 생길 시 이를 건너뛰고 다음 작업으로 이행하도록 해줌.
    expr = { # 함수에 대한 기술.
      xml_sjml <- read_xml(.x)
      xml_sjml_tb <- tibble(
        title = xml_text(xml_find_all(xml_sjml, "//title")), 
        category = xml_text(xml_find_all(xml_sjml, "//category")),
        author_age = as.numeric(xml_attr(xml_find_all(xml_sjml, "//author"), "age")),
        author_occupation = xml_attr(xml_find_all(xml_sjml, "//author"), "occupation"),
        author_sex = xml_attr(xml_find_all(xml_sjml, "//author"), "sex"),
        author_submission = xml_attr(xml_find_all(xml_sjml, "//author"), "submission"),
        author_handwriting = xml_attr(xml_find_all(xml_sjml, "//author"), "handwriting"),
        text_date = xml_attr(xml_find_all(xml_sjml, "//text"), "date"), # text 노드의 data 속성의 결과값 칼럼 만들기.
        text_subclass = xml_attr(xml_find_all(xml_sjml, "//text"), "subclass"), # text 노드의 subcless 속성의 결과값 칼럼 만들기.
        text = xml_find_all(xml_sjml, "//text/p") %>% 
          xml_text() %>% 
          str_c(collapse = " ") # 행갈이 단위로 분절된 텍스트를 띄어쓰기 단위로 이어주기. 
      )
      message(str_c("성공: ", .x , "에서 텍스트를 추출함.")) # 성공 메시지 출력하기.
      
      # 성공 시 결과 티블을 반환함.
      return(xml_sjml_tb)
    },
    error = function(err) {
      message(str_c("실패: ", .x, "에서 오류가 발생하여 건너뜀.")) # 문제가 있는 xml 파일은 텍스트 추출을 건너뜀.
      
      # 오류 시 빈 티블을 반환함.
      return(tibble())
    }
  )
})

# 최종결과 저장하기.
save(quiz_xml_result, file="quiz_xml_result.rda")

# 최종결과 확인하기.
quiz_xml_result

