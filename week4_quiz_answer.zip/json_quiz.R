# jsonlite 패키지 불러오기.
library(jsonlite)
library(tidyverse)

# json_week2 폴더 밑에 하위 폴더 published 만들기

dir.create("json_week2/quiz")

# JSON 파일 목록 불러오기.
json.list <- list.files(path = "json_week2/quiz", pattern = "^SDRW", recursive = T)
json.list.1 <- str_c("json_week2/quiz/", json.list)

# map 함수를 사용하여 목록 내 파일 일괄적으로 읽어들이기.
json.list.2 <- map(json.list.1, function(x) fromJSON(x, simplifyDataFrame = T))
json.list.2[[1]]

# 5개 JSON 파일에 대해 세 번째 리스트의 utterance, speaker, setting, topic 정보만 티블 형식으로 추출하도록 for 구문 작성.
json_text <- list()
json_metadata <- list()
json_setting <- list()
json_topic <- list()
for(i in seq_along(json.list.2)){
  json_text[[i]] <- map_dfr(json.list.2[[i]][[3]]$utterance, data.frame)
  json_metadata[[i]] <- map_dfr(json.list.2[[i]][[3]]$metadata$speaker, data.frame)
  json_setting[[i]] <- map_dfr(json.list.2[[i]][[3]]$metadata$setting, data.frame)
  json_topic[[i]] <- map_dfr(json.list.2[[i]][[3]]$metadata$topic, data.frame)
}

# 5개 구어 텍스트의 utterance와 그에 해당하는 speaker, setting, topic 메타데이터를 매칭하기.
json_join <- list()
for(i in seq_along(json.list.2)){
  json_join[[i]] <- json_metadata[[i]] %>%
    left_join(json_text[[i]], join_by(id == speaker_id)) %>% # utterance 정보 데이터프레임의 id와 speaker 정보 데이터프레임의 speaker_id를 연결고리로 하여 두 데이터프레임을 서로 합치기.
    bind_cols(json_setting[[i]], json_topic[[i]]) # setting 정보 데이터프레임과 topic 정보 데이터프레임까지 가로로 연결하여 합치기.
}

# 리스트 형식으로 추출된 결과물을 티블 형식으로 변환하기.
json_text.1 <- map_dfr(json_join, as_tibble) %>%
  rename(text = form, # form이라는 칼럼 제목을 text로 바꾸기.
         relation = `.x..i.....15`, # `.x..i.....15`라는 칼럼 제목을 relation으로 바꾸기.
         topic = `.x..i.....16`) %>% # `.x..i.....16`이라는 칼럼 제목을 topic으로 바꾸기.
  select(-id.y)
json_text.1

