library(rvest)
library(epubr)
library(tidyverse)

# 다운로드할 파일들이 들어 있는 URL을 url 객체에 할당하기.
main_url <- "https://www.gutenberg.org"

# URL에서 HTML 내용 읽어들이기.
main_page <- read_html(main_url)

# "a" 노드 중에서도 속성이 "href"인 링크만 추출하기.
book_links <- main_page %>%
  html_nodes("a") %>%
  html_attr("href") 

# 추출된 링크들 중에서 "/ebooks/" 뒤에 숫자가 붙는 링크만 필터링하기. 해당 링크만 실제 ebook 소개 페이지로 접속 가능.
book_links_tb <- as_tibble(book_links) %>%
  rename(link = value) %>%
  filter(str_detect(link, "^/ebooks/[0-9]{1,10}")) %>% # "/ebooks/" 뒤에 숫자(한 자리에서 열 자리까지)가 붙는 링크만 필터링하기.
  mutate(link = str_c("https://www.gutenberg.org", link)) %>% # 다운로드가 가능한 온전한 링크 주소 칼럼 생성하기.
  distinct() # 중복되는 행 제거하기.

# 최종결과 확인하기.
book_links_tb

# book_links_tb 티블의 link 칼럼 각 행을 처음부터 끝까지 돌며 find_epub_links() 함수를 적용한 뒤 그 결과를 데이터프레임 형식으로 저장하기.

epub_download_url <- map_dfr(book_links_tb$link, find_epub_links)

# 다운로드할 파일들이 들어 있는 URL을 url 객체에 할당하기.
main_url <- "https://www.gutenberg.org"

# URL에서 HTML 내용 읽어들이기.
main_page <- read_html(main_url)

# "a" 노드 중에서도 속성이 "href"인 링크만 추출하기.
book_links <- main_page %>%
  html_nodes("a") %>%
  html_attr("href") 

# 추출된 링크들 중에서 "/ebooks/" 뒤에 숫자가 붙는 링크만 필터링하기. 해당 링크만 실제 ebook 소개 페이지로 접속 가능.
book_links_tb <- as_tibble(book_links) %>%
  rename(link = value) %>%
  filter(str_detect(link, "^/ebooks/[0-9]{1,10}")) %>% # "/ebooks/" 뒤에 숫자(한 자리에서 열 자리까지)가 붙는 링크만 필터링하기.
  mutate(link = str_c("https://www.gutenberg.org", link)) %>% # 다운로드가 가능한 온전한 링크 주소 칼럼 생성하기.
  distinct() # 중복되는 행 제거하기.

# ebook 상세 페이지의 epub 다운로드 링크 찾아내 티블 형식으로 저장하기.
find_epub_links <- function(link){
  links <- read_html(link) %>%
    html_nodes("a") %>%
    html_attr("href")
  
  epub_links <- as_tibble(links) %>%
    rename(link = value) %>%
    filter(str_detect(link, "ebooks/[0-9]{1,10}.epub.images$")) %>%# epub.images로 끝나는 링크만 필터링하기.
    mutate(link = str_c("https://www.gutenberg.org", link))
  epub_links
}

# book_links_tb의 link 칼럼 첫 행부터 끝 행까지 find_epub_links() 함수를 적용한 다음, 이를 데이터프레임 형식으로 저장하기.
epub_download_url <- map_dfr(book_links_tb$link, find_epub_links)

# ebook을 다운받아 저장할 폴더 만들기.
download_directory <- "epub_week2/quiz"
dir.create(download_directory)

# 다운로드 링크와 파일 경로를 포함하는 티블 생성하기.
downloads_df <- epub_download_url %>%
  mutate(file_name = basename(link) %>%
           str_remove("\\.images$"), # 링크의 맨 끝 부분만 가져오되, ".images" 부분은 제거하기.
         file_path = file.path(download_directory, file_name) 
  )

# tidyverse의 walk2 함수를 통해 개별 링크마다 파일명을 작성하여 epub_week2/quiz 폴더에 저장하기.
walk2(
  .x = downloads_df$link, 
  .y = downloads_df$file_path, 
  .f = ~ download.file(url = .x, destfile = .y, mode = "wb") # 주의! mode = "wb"(binary 형식)로 지정하지 않으면 파일이 열리지 않음!
)

# epubr 패키지의 epub 함수를 적용하여 epub 파일들로부터 텍스트 추출하기.
epub.files <- downloads_df$file_path # 파일 경로(파일명)만 추출하기.
epub.df <- map_dfr(epub.files, epub) # 파일 경로 벡터에 대해 epub 함수 적용하기.
epub.df$data


## 서명, 언어, 작가명, 주제 정보를 data와 매칭시키기.

# for 구문을 사용하여 data 칼럼 수정 작업 하기.
for (i in 1:nrow(epub.df[, c(4,5,8,9,10)])) { # epub.df 티블에서 title, language, creator, subject, data 정보가 포함된 4, 5, 8, 9, 10번 칼럼만 추출하기.
  title <- epub.df$title[i] # 현재 행의 title 값 가져오기.
  language <- epub.df$language[i] # 현재 행의 language 값 가져오기.
  creator <- epub.df$creator[i] # 현재 행의 creator 값 가져오기.
  subject <- epub.df$subject[i] # 현재 행의 subject 값 가져오기.
  
  data_tibble <- epub.df$data[[i]] # 현재 행의 data 칼럼 티블 가져오기.
  new_data_tibble <- data_tibble %>% 
    mutate(
      title = title, # data 티블에 새 칼럼 title 추가하기.
      language = language, # data 티블에 새 칼럼 language 추가하기.
      creator = creator, # data 티블에 새 칼럼 creator 추가하기.
      subject = subject
    ) %>%
    relocate(title, language, creator, subject) # title, language, creator, subject 칼럼이 맨 앞에 오도록 순서 조정하기.
  
  epub.df$data[[i]] <- new_data_tibble # 수정된 티블을 data 칼럼에 할당하기.
}

week4.quiz.data.tibble <- map_dfr(epub.df$data, as_tibble) %>% # 리스트 형식인 epub.df$data를 행 단위로 쌓은 티블 형식으로 변환하기.
  filter(str_detect(section, "cov|Cov|toc|TOC|pg-header|pg-footer") == F) # cover, 목차, pg-header, pg-footer 관련 정보는 제거하기.
save(week4.quiz.data.tibble, file="week4.quiz.data.tibble.rda") # 나중을 위해 객체 저장하기.
write_csv(week4.quiz.data.tibble, "week4.quiz.data.tibble.csv") # csv 파일 형태로 저장하기.

# 최종결과 확인하기.
week4.quiz.data.tibble %>%
  View()
