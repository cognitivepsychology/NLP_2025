##### 퀴즈 1 #####

# 1. 올려드린 5개의 JSON 파일(국립국어원 구어 말뭉치 중 일부)을 json_week2 폴더 밑 하위 폴더 quiz에 저장하세요. dir.create("json_week2/quiz") 코드를 실행하면 하위 폴더 quiz가 자동 생성됩니다.
# 2. quiz 폴더 내 "SDRW"로 시작하는 JSON 파일들의 목록을 불러온 뒤, 파일 경로를 만들어주세요.
# 3.  fromJSON() 함수와 map() 함수를 사용하여 목록 내 파일들을 일괄적으로 R로 읽어들이세요.
# 4. 5개 JSON 파일에 대해 세 번째 리스트(document 리스트)의  utterance, speaker, setting, topic 정보만 데이터프레임 형식으로 추출하도록 for 구문을 작성하세요. setting과 topic 정보를 데이터프레임 형식으로 추출하는 방법은 speaker 정보를 추출하는 방식과 동일합니다.
# 5. 5개 구어 utterance와 speaker, setting, topic 메타데이터를 짝에 맞게 매칭해주세요. utterance와 speaker 정보는 left_join() 함수로 매칭해주세요. 그리고 setting과 topic 정보는 bind_cols() 함수(여러 개의 데이터프레임을 가로로 연결하여 합쳐줌) 안에 넣어 합쳐주세요. 5번은 수업에서 알려드린 json_join 생성용 for 구문 안에 bind_cols() 함수를 사용한 코드 한 줄만 추가하면 됩니다. 해당 함수의 사용법에 대해서는 AI에 문의해도 좋습니다.
# 6. 5번의 결과물(다섯 개의 데이터프레임으로 구성된 리스트)에 대해 map_dfr() 함수를 적용하여 티블 형식으로 변환해주세요. 결과물은 "json_text.1"이라는 이름의 객체에 할당합니다.
# 7. 만약에 `.x..i.....15`라는 제목의 칼럼이 있다면 relation으로, `.x..i.....16`이라는 제목의 칼럼이 있다면 topic으로 칼럼 제목을 바꿔주세요. 보다시피 원 칼럼 제목은 정상적인 알파벳으로 이루어져 있지 않으므로, ``(backtick)으로 감싸는 걸 잊지 마세요. 
# 8. id.y 칼럼을 제거해주세요.
# 9. 객체 "json_text.1"를 확인해주세요.
# 10. 본 R 스크립트 파일을 "json_quiz.R"이라는 이름으로 저장하여 업로드하세요.

# jsonlite 패키지 불러오기.
library(jsonlite)
library(tidyverse)

# json_week2 폴더 밑에 하위 폴더 published 만들기

dir.create("json_week2/quiz")

# JSON 파일 목록 불러오기.
json.list <- list.files(path = "json_week2/quiz", pattern = "^SDRW", recursive = T)
json.list.1 <- str_c("json_week2/quiz/", json.list)

# map 함수를 사용하여 목록 내 파일 일괄적으로 읽어들이기.
json.list.2 <- map(json.list.1, function(x) fromJSON(x, simplifyDataFrame = T))
json.list.2[[1]]

# 5개 JSON 파일에 대해 세 번째 리스트의 utterance, speaker, setting, topic 정보만 티블 형식으로 추출하도록 for 구문 작성.
json_text <- list()
json_metadata <- list()
json_setting <- list()
json_topic <- list()
for(i in seq_along(json.list.2)){
  json_text[[i]] <- map_dfr(json.list.2[[i]][[3]]$utterance, data.frame)
  json_metadata[[i]] <- map_dfr(json.list.2[[i]][[3]]$metadata$speaker, data.frame)
  json_setting[[i]] <- map_dfr(json.list.2[[i]][[3]]$metadata$setting, data.frame)
  json_topic[[i]] <- map_dfr(json.list.2[[i]][[3]]$metadata$topic, data.frame)
}

# 5개 구어 텍스트의 utterance와 그에 해당하는 speaker, setting, topic 메타데이터를 매칭하기.
json_join <- list()
for(i in seq_along(json.list.2)){
  json_join[[i]] <- json_metadata[[i]] %>%
    left_join(json_text[[i]], join_by(id == speaker_id)) %>% # utterance 정보 데이터프레임의 id와 speaker 정보 데이터프레임의 speaker_id를 연결고리로 하여 두 데이터프레임을 서로 합치기.
    bind_cols(json_setting[[i]], json_topic[[i]]) # setting 정보 데이터프레임과 topic 정보 데이터프레임까지 가로로 연결하여 합치기.
}

# 리스트 형식으로 추출된 결과물을 티블 형식으로 변환하기.
json_text.1 <- map_dfr(json_join, as_tibble) %>%
  rename(text = form, # form이라는 칼럼 제목을 text로 바꾸기.
         relation = `.x..i.....15`, # `.x..i.....15`라는 칼럼 제목을 relation으로 바꾸기.
         topic = `.x..i.....16`) %>% # `.x..i.....16`이라는 칼럼 제목을 topic으로 바꾸기.
  select(-id.y)
json_text.1


##### 퀴즈 2 #####

# 1. 올려드린 50개의 XML 파일을 xml_week2 폴더 밑 하위 폴더 quiz에 저장하세요. dir.create("xml_week2/quiz") 코드를 실행하면 하위 폴더 quiz가 자동 생성됩니다.
# 2. quiz 폴더 내 "sjml"로 끝나는 XML 파일들(총 50개)의 목록을 불러온 뒤, 파일 경로를 만들어주세요.
# 3. read_xml() 함수와 map_dfr() 함수를 이용하여 50개의  XML 파일을 한꺼번에 불러와 티블로 만드세요. 티블에 들어갈 칼럼은 총 9개로, title, category, author_age, author_occupation, author_sex, author_submission, author_handwriting, text_date, 그리고 text_subclass입니다. text_date는 text 노드의 date 속성, text_subclass는 text 노드의 subclass 속성을 가져오면 됩니다. 결과물은 "quiz_xml_result"라는 이름의 객체에 할당합니다.
# 4. 연속작업 시 오류 파일은 건너뛰도록 tryCatch() 함수를 사용하세요.
# 5. 객체 "quiz_xml_result"를 "quiz_xml_result.rda" 파일로 저장하세요.
# 6. 객체 "quiz_xml_result"를 확인해주세요.
# 7. 본 R 스크립트 파일을 "xml_quiz.R"이라는 이름으로 저장하여 업로드하세요.


# xml2 패키지 불러오기.
library(xml2)
library(tidyverse)

# xml_week2 폴더 밑에 하위 폴더 quiz 만들기.
dir.create("xml_week2/quiz")

# xml 파일 목록 불러온 뒤 파일 경로 생성하기.
xml_list <- list.files(path = "xml_week2/quiz", pattern = "sjml$", recursive = T)
xml_list.1 <- str_c("xml_week2/quiz/", xml_list)

# 여러 개의 XML 파일을 한꺼번에 불러와 티블로 만들기.
quiz_xml_result <- map_dfr(xml_list.1, ~{
  tryCatch( # 연속작업 실행 중 오류가 생길 시 이를 건너뛰고 다음 작업으로 이행하도록 해줌.
    expr = { # 함수에 대한 기술.
      xml_sjml <- read_xml(.x)
      xml_sjml_tb <- tibble(
        title = xml_text(xml_find_all(xml_sjml, "//title")), 
        category = xml_text(xml_find_all(xml_sjml, "//category")),
        author_age = as.numeric(xml_attr(xml_find_all(xml_sjml, "//author"), "age")),
        author_occupation = xml_attr(xml_find_all(xml_sjml, "//author"), "occupation"),
        author_sex = xml_attr(xml_find_all(xml_sjml, "//author"), "sex"),
        author_submission = xml_attr(xml_find_all(xml_sjml, "//author"), "submission"),
        author_handwriting = xml_attr(xml_find_all(xml_sjml, "//author"), "handwriting"),
        text_date = xml_attr(xml_find_all(xml_sjml, "//text"), "date"), # text 노드의 data 속성의 결과값 칼럼 만들기.
        text_subclass = xml_attr(xml_find_all(xml_sjml, "//text"), "subclass"), # text 노드의 subcless 속성의 결과값 칼럼 만들기.
        text = xml_find_all(xml_sjml, "//text/p") %>% 
          xml_text() %>% 
          str_c(collapse = " ") # 행갈이 단위로 분절된 텍스트를 띄어쓰기 단위로 이어주기. 
      )
      message(str_c("성공: ", .x , "에서 텍스트를 추출함.")) # 성공 메시지 출력하기.
      
      # 성공 시 결과 티블을 반환함.
      return(xml_sjml_tb)
    },
    error = function(err) {
      message(str_c("실패: ", .x, "에서 오류가 발생하여 건너뜀.")) # 문제가 있는 xml 파일은 텍스트 추출을 건너뜀.
      
      # 오류 시 빈 티블을 반환함.
      return(tibble())
    }
  )
})

# 최종결과 저장하기.
save(quiz_xml_result, file="quiz_xml_result.rda")

# 최종결과 확인하기.
quiz_xml_result


##### 퀴즈 3 #####

# 1. 저작권이 만료된 해외 무료 ebook을 모아놓은 https://www.gutenberg.org 에 가보세요. 
# 2. 다음은 https://www.gutenberg.org의 메인 페이지에 떠 있는 ebook들의 상세 페이지 링크 주소를 추출하는 코드입니다. book_links_tb을 실행하여 링크 주소를 확인하세요.

library(rvest)
library(epubr)
library(tidyverse)

# 다운로드할 파일들이 들어 있는 URL을 url 객체에 할당하기.
main_url <- "https://www.gutenberg.org"

# URL에서 HTML 내용 읽어들이기.
main_page <- read_html(main_url)

# "a" 노드 중에서도 속성이 "href"인 링크만 추출하기.
book_links <- main_page %>%
  html_nodes("a") %>%
  html_attr("href") 

# 추출된 링크들 중에서 "/ebooks/" 뒤에 숫자가 붙는 링크만 필터링하기. 해당 링크만 실제 ebook 소개 페이지로 접속 가능.
book_links_tb <- as_tibble(book_links) %>%
  rename(link = value) %>%
  filter(str_detect(link, "^/ebooks/[0-9]{1,10}")) %>% # "/ebooks/" 뒤에 숫자(한 자리에서 열 자리까지)가 붙는 링크만 필터링하기.
  mutate(link = str_c("https://www.gutenberg.org", link)) %>% # 다운로드가 가능한 온전한 링크 주소 칼럼 생성하기.
  distinct() # 중복되는 행 제거하기.

# 최종결과 확인하기.
book_links_tb

# 3. 해당 사이트 메인 페이지의 아무 책이나 클릭하여 들어가보세요.그리고 접속한 ebook 상세 페이지의 html 구조를 주의 깊게 관찰하세요.
# 4. 해당 ebook의 epub 파일 다운로드 링크가 어디에 있는지 찾아보세요. 참고로, 이번에도 "a" 노드의 "href" 속성에 들어 있습니다.
# 5. 이제부터 여러분은 find_epub_links()라는 이름의 함수를 직접 제작해야 합니다. 이 함수는 상세 페이지 링크 주소를 넣으면 epub 파일을 다운받을 수 있는 링크 티블을 반환해줍니다.
# 6. 해당 티블은 epub 다운로드 링크 주소가 link라는 칼럼에 들어야 있어야 합니다. 이때 동일 epub 파일의 중복 다운로드를 방지하기 위해 "ebooks/" 뒤에 숫자가 오는 링크만 필터링합니다. "ebooks/[0-9]{1,10}"이라는 정규표현식을 활용하면 됩니다. epub_links 객체를 생성하는 코드(수업시간에 배운)를 살짝만 응용해주세요. 
# 7. 그럼 이제 다음의 코드를 실행하세요. book_links_tb 티블의 link 칼럼 각 행을 처음부터 끝까지 돌며 find_epub_links() 함수를 적용한 뒤 그 결과를 데이터프레임 형식으로 저장합니다. 

epub_download_url <- map_dfr(book_links_tb$link, find_epub_links)

# 8. dir.create() 함수를 사용하여 epub_week2 폴더 밑에 quiz라는 하위 폴더를 생성하세요.
# 9. epub 파일 다운로드 링크와 파일 저장 경로를 포함하는 티블을 생성하세요. 지금까지 정확하게 코드를 작성하셨다면, "file_name = basename(link)" 적용 시 확장자가 epub가 아니게 됩니다. "file_name = basename(link) %>% str_remove("\\.images$")" 코드를 적용하여 맨끝의 ".images"라는 문자열을 제거해주세요. 
# 10. tidyverse의 walk2 함수를 사용하여 개별 링크마다 파일 저장 경로를 만든 뒤 epub_week2 밑 quiz 폴더에 저장하세요.
# 11. epubr 패키지의 epub 함수를 적용하여 다운받은 epub 파일들로부터 텍스트를 추출하세요. 결과물은 epub.df라는 이름의 객체에 할당합니다.
# 12. for 구문을 사용하여 title, language, creator, subject를 data와 매칭시키세요. 이때 title, language, creator, subject 칼럼이 맨 앞에 오도록 순서를 조정합니다.
# 13. epub.df$data는 아직 리스트 형식입니다. epub.df$data를 행 단위로 쌓은 티블 형식으로 변환하세요. 이때 cover, 목차, pg-header, pg-footer 관련 정보는 제거하세요. 최종 결과물은 week4.quiz.data.tibble 객체에 할당합니다.
# 14. save() 함수를 사용하여 week4.quiz.data.tibble 객체를 rda 파일로 저장하세요.
# 15. wrtie_csv() 함수를 사용하여 csv 파일 형태로 저장하세요. 결코 엑셀에서 해당 csv 파일을 열지 마세요. 인코딩 문제로 글자가 깨져 보일 것이며, 그것이 정상입니다. 윈도우 사용자라면 NotePad++에서 열어보시면 됩니다.
# 16. 본 R 스크립트 파일을 "epub_quiz.R"이라는 이름으로 저장하여 rda 파일 및 csv 파일과 함께 업로드하세요.

library(rvest)
library(epubr)

# 다운로드할 파일들이 들어 있는 URL을 url 객체에 할당하기.
main_url <- "https://www.gutenberg.org"

# URL에서 HTML 내용 읽어들이기.
main_page <- read_html(main_url)

# "a" 노드 중에서도 속성이 "href"인 링크만 추출하기.
book_links <- main_page %>%
  html_nodes("a") %>%
  html_attr("href") 

# 추출된 링크들 중에서 "/ebooks/" 뒤에 숫자가 붙는 링크만 필터링하기. 해당 링크만 실제 ebook 소개 페이지로 접속 가능.
book_links_tb <- as_tibble(book_links) %>%
  rename(link = value) %>%
  filter(str_detect(link, "^/ebooks/[0-9]{1,10}")) %>% # "/ebooks/" 뒤에 숫자(한 자리에서 열 자리까지)가 붙는 링크만 필터링하기.
  mutate(link = str_c("https://www.gutenberg.org", link)) %>% # 다운로드가 가능한 온전한 링크 주소 칼럼 생성하기.
  distinct() # 중복되는 행 제거하기.

# ebook 상세 페이지의 epub 다운로드 링크 찾아내 티블 형식으로 저장하기.
find_epub_links <- function(link){
  links <- read_html(link) %>%
    html_nodes("a") %>%
    html_attr("href")
  
  epub_links <- as_tibble(links) %>%
    rename(link = value) %>%
    filter(str_detect(link, "ebooks/[0-9]{1,10}.epub.images$")) %>%# epub.images로 끝나는 링크만 필터링하기.
    mutate(link = str_c("https://www.gutenberg.org", link))
  epub_links
}

# book_links_tb의 link 칼럼 첫 행부터 끝 행까지 find_epub_links() 함수를 적용한 다음, 이를 데이터프레임 형식으로 저장하기.
epub_download_url <- map_dfr(book_links_tb$link, find_epub_links)

# ebook을 다운받아 저장할 폴더 만들기.
download_directory <- "epub_week2/quiz"
dir.create(download_directory)

# 다운로드 링크와 파일 경로를 포함하는 티블 생성하기.
downloads_df <- epub_download_url %>%
  mutate(file_name = basename(link) %>%
           str_remove("\\.images$"), # 링크의 맨 끝 부분만 가져오되, ".images" 부분은 제거하기.
         file_path = file.path(download_directory, file_name) 
  )

# tidyverse의 walk2 함수를 통해 개별 링크마다 파일명을 작성하여 epub_week2/quiz 폴더에 저장하기.
walk2(
  .x = downloads_df$link, 
  .y = downloads_df$file_path, 
  .f = ~ download.file(url = .x, destfile = .y, mode = "wb") # 주의! mode = "wb"(binary 형식)로 지정하지 않으면 파일이 열리지 않음!
)

# epubr 패키지의 epub 함수를 적용하여 epub 파일들로부터 텍스트 추출하기.
epub.files <- downloads_df$file_path # 파일 경로(파일명)만 추출하기.
epub.df <- map_dfr(epub.files, epub) # 파일 경로 벡터에 대해 epub 함수 적용하기.
epub.df$data


## 서명, 언어, 작가명, 주제 정보를 data와 매칭시키기.

# for 구문을 사용하여 data 칼럼 수정 작업 하기.
for (i in 1:nrow(epub.df[, c(4,5,8,9,10)])) { # epub.df 티블에서 title, language, creator, subject, data 정보가 포함된 4, 5, 8, 9, 10번 칼럼만 추출하기.
  title <- epub.df$title[i] # 현재 행의 title 값 가져오기.
  language <- epub.df$language[i] # 현재 행의 language 값 가져오기.
  creator <- epub.df$creator[i] # 현재 행의 creator 값 가져오기.
  subject <- epub.df$subject[i] # 현재 행의 subject 값 가져오기.
  
  data_tibble <- epub.df$data[[i]] # 현재 행의 data 칼럼 티블 가져오기.
  new_data_tibble <- data_tibble %>% 
    mutate(
      title = title, # data 티블에 새 칼럼 title 추가하기.
      language = language, # data 티블에 새 칼럼 language 추가하기.
      creator = creator, # data 티블에 새 칼럼 creator 추가하기.
      subject = subject
    ) %>%
    relocate(title, language, creator, subject) # title, language, creator, subject 칼럼이 맨 앞에 오도록 순서 조정하기.
  
  epub.df$data[[i]] <- new_data_tibble # 수정된 티블을 data 칼럼에 할당하기.
}

week4.quiz.data.tibble <- map_dfr(epub.df$data, as_tibble) %>% # 리스트 형식인 epub.df$data를 행 단위로 쌓은 티블 형식으로 변환하기.
  filter(str_detect(section, "cov|Cov|toc|TOC|pg-header|pg-footer") == F) # cover, 목차, pg-header, pg-footer 관련 정보는 제거하기.
save(week4.quiz.data.tibble, file="week4.quiz.data.tibble.rda") # 나중을 위해 객체 저장하기.
write_csv(week4.quiz.data.tibble, "week4.quiz.data.tibble.csv") # csv 파일 형태로 저장하기.

# 최종결과 확인하기.
week4.quiz.data.tibble %>%
  View()
