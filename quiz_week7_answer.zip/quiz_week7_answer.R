### 퀴즈 1 ###

library(reticulate)
library(bitNLP)
library(stringi)
use_condaenv("my_env")
kiwiquiz <- import("kiwipiepy")$Kiwi()

analyze_pos_kiwiquiz <- function(text) {
  results <- kiwiquiz$analyze(text)
  tagged_tokens <- map_dfr(results[[1]][[1]], ~tibble(
    morph = .x$form,
    pos = .x$tag 
  ))
  stop_words_pos <- c("이/VCP", "것/NNB", "곳/NNG", "곳/NNB", "하/VX", "하/VV", "수/NNB", "되/VV", 
                      "하/XSA", "들/XSN", "되/XSA", "되/XSV", "하/XSV", "이/VCP", "이/VV", "적/XSN")
  filtered_tokens <- tagged_tokens %>%
    filter(!str_detect(pos, "^J"),
           !str_detect(pos, "^E"),
           !str_detect(pos, "SF|SP|SS")
    ) %>%
    mutate(tagged_morph = str_c(morph, "/", pos)) %>%
    filter(!tagged_morph %in% stop_words_pos)
  
  return(list(tagged_morphs = filtered_tokens$tagged_morph))
}

game_train <- read_delim("game_train.txt") 
game_test <- read_delim("game_test.txt")

set.seed(1234)
game_train <- sample_n(game_train, size = 1000) %>%
  mutate(id = row_number())

set.seed(1234)
game_test <- sample_n(game_test, size = 1000) %>%
  mutate(id = row_number())

game_train_tokenized <- game_train %>%
  filter(document != "") %>%
  drop_na() %>%
  mutate(document = stri_enc_toutf8(document), 
         document_tagged = map(document, analyze_pos_kiwiquiz),
         document_tagged = map_chr(document_tagged, ~str_c(.x$tagged_morphs, collapse = " "))
  ) %>% 
  mutate(morp = str_remove_all(document_tagged, "-[A-Z]{1,3}|/[A-Z]{1,3}"))

game_test_tokenized <- game_test %>%
  filter(document != "") %>%
  drop_na() %>%
  mutate(document = stri_enc_toutf8(document), 
         document_tagged = map(document, analyze_pos_kiwiquiz),
         document_tagged = map_chr(document_tagged, ~str_c(.x$tagged_morphs, collapse = " "))
  ) %>% 
  mutate(morp = str_remove_all(document_tagged, "-[A-Z]{1,3}|/[A-Z]{1,3}"))

word_tokens <- game_train_tokenized %>%
  unnest_tokens(word, morp) %>%
  filter(!word %in% c("게임", "겜")) %>% 
  distinct(id, word, label) 

min_frequency <- 2 

word_counts <- word_tokens %>%
  count(word, sort = TRUE) %>% 
  filter(n >= min_frequency) %>% 
  mutate(p_word = n / sum(n)) 

word_tokens <- word_tokens %>% 
  semi_join(word_counts, by = "word") 

sentiment_counts <- word_tokens %>%
  distinct(id, label) %>% 
  count(label) %>% 
  mutate(p_sentiment = n / sum(n))

word_sentiment_pairs <- word_tokens %>%
  count(word, label, sort = TRUE) %>% 
  mutate(p_word_sentiment = n / sum(n))

pmi_scores <- word_sentiment_pairs %>%
  left_join(word_counts, by = "word") %>%
  left_join(sentiment_counts, by = "label") %>%
  mutate(pmi = log2(p_word_sentiment / (p_word * p_sentiment))) %>% 
  select(word, label, pmi) %>% 
  arrange(desc(pmi)) 

sentiment_score <- pmi_scores %>%
  select(word, label, pmi) %>% 
  pivot_wider(names_from = label, values_from = pmi, values_fill = 0) %>% 
  mutate(score = `1` - `0`) %>% 
  arrange(desc(score)) %>% 
  rename(negative = `0`, positive = `1`) %>%
  mutate(senti_label = case_when(score > 0 ~  "긍정", 
                                 T ~ "부정")) 

top_words <- sentiment_score %>%
  filter(score != 0) %>%
  slice_max(abs(score), n = 30) %>% 
  mutate(direction = case_when(score > 0 ~  "positive", 
                               T ~ "negative"))

# 폰트 등록
library(showtext)
font_add("MalgunGothic", "C:/Windows/Fonts/malgun.ttf")
showtext_auto()

# ggplot2 패키지로 시각화하기.
game_review_plot <- ggplot(top_words, aes(x = reorder(word, score), y = score, fill = direction)) + 
  geom_col(show.legend = FALSE) + 
  coord_flip() + 
  scale_fill_manual(values = c("positive" = "steelblue", "negative" = "tomato")) +
  labs(
    title = "PMI 기반 감성점수 상위단어", 
    x = "단어", 
    y = "감성점수 (PMI 차이)"
  ) +
  theme_minimal() + 
  theme(text = element_text(family = "MalgunGothic"),
        axis.text.x = element_text(size = 14),  
        axis.text.y = element_text(size = 14),  
        axis.title.x = element_text(size = 16), 
        axis.title.y = element_text(size = 16), 
        plot.title = element_text(size = 16, face = "bold", hjust = 0.5)
  )

# 그래프를 png 형식으로 출력하기.
png(filename = "game_review_plot.png", width = 1000, height = 1000, type = "cairo", 
    antialias = "subpixel", family = "MalgunGothic", res = 220)
game_review_plot
dev.off() 

### 퀴즈 2 ###

word_tokens <- game_test_tokenized %>%
  unnest_tokens(word, morp) %>%
  filter(!word %in% c("게임", "겜")) %>% 
  distinct(id, word, label) 

min_frequency <- 2 

word_counts <- word_tokens %>%
  count(word, sort = TRUE) %>% 
  filter(n >= min_frequency) %>% 
  mutate(p_word = n / sum(n))

word_tokens <- word_tokens %>%
  semi_join(word_counts, by = "word") 

sentiment_counts <- word_tokens %>%
  distinct(id, label) %>%
  count(label) %>% 
  mutate(p_sentiment = n / sum(n))

word_sentiment_pairs <- word_tokens %>%
  count(word, label, sort = TRUE) %>% 
  mutate(p_word_sentiment = n / sum(n))

pmi_scores <- word_sentiment_pairs %>%
  left_join(word_counts, by = "word") %>% 
  left_join(sentiment_counts, by = "label") %>% 
  mutate(pmi = log2(p_word_sentiment / (p_word * p_sentiment))) %>% # PMI 계산하기.
  select(word, label, pmi) %>%
  arrange(desc(pmi))

sentiment_score <- pmi_scores %>%
  select(word, label, pmi) %>% 
  pivot_wider(names_from = label, values_from = pmi, values_fill = 0) %>% 
  mutate(score = `1` - `0`) %>% 
  arrange(desc(score)) %>% 
  rename(negative = `0`, positive = `1`) %>%
  mutate(senti_label = case_when(score > 0 ~  "긍정",
                                 T ~ "부정"))

game_test_with_score <- game_test_tokenized %>%
  mutate(
    total_senti_score = map_dbl(morp, ~ {
      morp_words <- str_split(.x, " ")[[1]]
      matched_scores <- sentiment_score %>%
        filter(word %in% morp_words) %>%
        pull(score)
      sum(matched_scores)
    })
  ) %>%
  mutate(polarity = case_when(total_senti_score > 0 ~ 1,
                              T ~ 0),
         total_senti_logical = case_when(polarity == label ~ T, 
                                         polarity != label ~ F) 
  )

game_test_SA_precision <- game_test_with_score %>%
  group_by(total_senti_logical) %>% 
  count() %>%
  ungroup() %>%
  summarise(accuracy = n[2]/(n[1]+n[2])) # PMI 기반 극성 분류의 정확도 = 0.862.

### 퀴즈 3 ###

options(tibble.width = Inf)
library(bitNLP)
library(tidyverse)
library(tidytext)
data(buzz)

buzz.1 <- buzz %>% 
  filter(DOC_KEY %in% c("20180427175832431000YOcVw", "20180426201504042000MMzmt", "20170928180539603053pZMSW", "20170928215503372815hHatF")) %>%
  unnest_tokens(sentence, CONTENT, token = "sentences") 

buzz.2 <- buzz.1 %>%
  filter(TITLE %in% c(" 굴복시키려는 그 쪽 집 어머니 진짜 미치겠어요.", " 가난한 친정은싫고 보살핌은 받고싶은 친언니", 
                      "4개월 아기 보고싶다고 너무 이기적인 시어머니", "부모님이 아이들 봐주시나요 얘기좀 나눠주세요. .")) %>%
  unnest_tokens(sentence, sentence, token = "sentences") %>% 
  group_by(TITLE) %>%
  mutate(sentence_id = row_number()) 

buzz.3 <- buzz.2 %>%
  ungroup() %>% 
  unnest_tokens(word, sentence, token = "words") %>% 
  left_join(sentiment_dic, by = "word") %>% 
  group_by(TITLE, sentence_id) %>% 
  summarise(sentiment_score = sum(polarity, na.rm = TRUE)) 

# 폰트 등록
library(showtext)
font_add("MalgunGothic", "C:/Windows/Fonts/malgun.ttf")
showtext_auto()

cafe_buzz_plot <- buzz.3 %>%
  ggplot(aes(x = sentence_id, y = sentiment_score, group = TITLE)) +
  geom_line(color = "steelblue", linewidth = 1.5) + 
  facet_wrap(~ TITLE) + 
  labs(
    title = "KNU 사전 기반 감정곡선", 
    x = "문장번호", 
    y = "감성점수" 
  ) +
  theme(text = element_text(family = "MalgunGothic"),
        axis.text.x = element_text(size = 14),
        axis.text.y = element_text(size = 14),
        axis.title.x = element_text(size = 16),
        axis.title.y = element_text(size = 16),
        plot.title = element_text(size = 16, face = "bold", hjust = 0.5), 
        strip.text = element_text(size = 16) 
  )

# 그래프를 png 형식으로 출력하기.
png(filename = "cafe_buzz_plot.png", width = 1200, height = 1200, type = "cairo", 
    antialias = "subpixel", family = "MalgunGothic", res = 220)
cafe_buzz_plot
dev.off() 
