library(tidyverse)
library(tuber) # 유튜브를 키워드로 검색하여 정보를 가져오는 패키지 불러오기.
library(httpuv)
library(httr)

# 1. YouTube OAuth 2.0 인증하기.
yt_oauth(app_id = my_app_id, app_secret = my_app_secret, token = my_apiKey)

# 2. 검색할 키워드 설정하기.
keyword <- "먹방"

# 3. 유튜브에서 영상 검색하기.
search_results <- yt_search( # yt_search() 함수를 사용하여 키워드에 해당하는 영상정보 가져오기.
  term = keyword, # 검색 키워드 설정하기.
  type = "video", # 영상만 검색하도록 지정하기.
  max_results = 20 # 한 번에 가져올 결과의 최대 개수 지정하기.
)
# 4. 영상 URL 목록 추출하기.
video_ids <- search_results$video_id # 검색결과 데이터프레임에서 videoId 칼럼만 가져오기.

# 5. 영상 ID를 유튜브 URL 형식으로 변환하기.
video_urls <- str_c("https://www.youtube.com/watch?v=", video_ids)

# 6. 결과 확인하기
video_urls[1:10]

library(curl) # 제대로 설치되어 있지 않은 경우 오류가 생길 수 있음. 이미 설치되어 있어도 재설치 권장.
library(writexl) # R 데이터 프레임 객체를 엑셀 형식으로 저장할 수 있도록 해주는 패키지.
library(vosonSML)

# 유튜브 데이터에 접근할 수 있는 auth 객체 생성하기.
youtubeAuth <- Authenticate("youtube", apiKey = my_apiKey)

# 수집된 유튜브 영상 URL 목록을 다른 이름으로 재지정하기(optional).
video_ids_voson <- video_urls # video_urls을 video_ids_voson라는 이름으로 다시 지정하기.

# 개별 유튜브 영상당 최대 20여 개의 댓글 수집하기.
mb_youtube_comment <- youtubeAuth %>%
  Collect(videoIDs = video_ids_voson, maxComments = 20)
View(mb_youtube_comment)

write_xlsx(mb_youtube_comment, "mb_youtube_comment_voson.xlsx") # 수집된 댓글 목록을 엑셀 형식으로 저장하기.
