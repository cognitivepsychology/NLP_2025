library(tidyverse)
library(rvest) # 웹 스크래핑 패키지.
library(readxl) # 엑셀 파일을 R로 읽어들일 수 있도록 해주는 패키지.

# 빅카인즈 사이트에서 검색한 결과물(엑셀 스프레드 시트 형식)을 R로 불러들이기.
kinds.results <- read_excel("NewsResult_20240903-20250903.xlsx")

# 한국일보 기사를 저장할 하위 디렉토리 생성하기.
dir.create("article_week2/hk")

# 한국일보 기사의 url만 추려내기.
kinds.results.hk.url <- kinds.results %>%
  filter(`언론사` == "한국일보") %>%
  select(URL) %>%
  mutate(file_name = str_c("article_week2/hk/", "hk", row_number(), ".txt")) # 특정 url에 해당하는 기사를 저장할 파일의 경로를 기록해둔 칼럼 만들기.

# tryCatch 함수를 사용하여 오류 url 건너뛸 수 있는 함수 자체 제작하기.
a.extract.hk <- function(url, file_name){
  walk2(.x = url, .y = file_name, ~ {
    tryCatch( # 연속작업 실행 중 오류가 생길 시 이를 건너뛰고 다음 작업으로 이행하도록 해줌.
      expr = { # 함수에 대한 기술.
        hk_article <- read_html(.x) %>%
          html_nodes(".editor-p") %>%
          html_text2()
        
        write_lines(hk_article, .y) # 추출된 텍스트를 파일로 저장하기
        
        message(str_c("성공: ", .x , "에서 기사를 추출한 뒤 ", .y, "에 저장함.")) # 성공 메시지 출력하기.
      },
      error = function(err){ # 오류처리에 대한 기술.
        message(str_c("실패: ", .x, "에서 오류가 발생하여 건너뜀.")) # 실패 메시지 출력하기.
      }
    )
  })
}

# 자체 제작 함수를 실행하여 article_week2 폴더에 추출된 기사 txt 파일 일괄 저장하기.
a.extract.hk(kinds.results.hk.url$URL, kinds.results.hk.url$file_name)