### 퀴즈 1 ###

library(tidyverse)          
library(quanteda)           
library(cluster)
library(FactoMineR)
library(factoextra)
options(tibble.width = Inf)

load("unsupervised.dataset_tokenized_quiz.rda")
q1_pca <- pca_result <- PCA(
  tfidf_matrix , # 입력 데이터(숫자 행렬): 기본 매트릭스 적용.
  scale.unit = FALSE, # 이미 앞서 tfidf_matrix 생성 시 표준화를 적용했으므로 다시 표준화를 적용할 필요 없음.
  ncp= 5,
  graph = FALSE # FactoMineR 자체 그래프는 끔(factoextra 사용).
)
save(q1_pca, file="q1_pca.rda")

uns_quiz_plot <- fviz_eig(
  pca_result, # PCA 결과 객체.
  addlabels = TRUE, # 막대 위에 분산(%) 표시.
  ncp = 10 #상위 10개 PC만 표시.
)
ggsave(" uns_quiz_plot.png", uns_quiz_plot, width = 10, height = 10)
uns_quiz_plot

# 5/6번째 PC에서 플롯이 급격히 꺾임. PC1과 PC2는 각각 원본 데이터의 1.3%와 1%의 분산을 설명해줌.

### 퀴즈 2 ###

uns_pc1_contrib_quiz_plot <- fviz_contrib(q1_pca, # PCA 결과 객체.
                                          choice = "var", # '변수(variable)'의 기여도를 보겠음.
                                          axes = 1, # 'PC1' 축에 대한 기여도.
                                          top = 10  # 기여도가 가장 높은 상위 10개 단어만 표시.
                                          )
ggsave("uns_pc1_contrib_quiz_plot.png", uns_pc1_contrib_quiz_plot, width = 10, height = 10)
uns_pc1_contrib_quiz_plot

# 먹, 맛있, 배달, 시키, 커피, 치킨 같은 단어들이 10대 논항에 포함되어 있음. 이는 식음료 관련 주제와 관련이 있는 것으로 추정됨. 먹은 먹-(eat)의 어간, 맛있은 맛있-(delicious), 배달은 음식 배달, 시키도 주문을 의미하는 시키-(order)의 어간, 커피는 한국인이 가장 자주 마시는 음료 중 하나, 치킨 역시 가장 인기 있는 배달음식 중 하나를 의미하는 것으로 추정되기 때문임.

uns_pc2_contrib_quiz_plot <- fviz_contrib(q1_pca, # PCA 결과 객체.
                                          choice = "var", # '변수(variable)'의 기여도를 보겠음.
                                          axes = 2, # 'PC2' 축에 대한 기여도.
                                          top = 10  # 기여도가 가장 높은 상위 10개 단어만 표시.
                                          )
ggsave("uns_pc2_contrib_quiz_plot.png", uns_pc2_contrib_quiz_plot, width = 10, height = 10)
uns_pc2_contrib_quiz_plot

# 차, 타, 버스, 택시, 지하철 같은 단어들이 10대 논항에 포함되어 있음. 이는 교통 관련 주제와 관련이 있는 것으로 추정됨. 차는 자동차, 타는 타-(ride)의 어간, 버스, 택시, 지하철은 대중교통 수단을 의미하는 것으로 추정되기 때문임.

### 퀴즈 3 ###

library(reticulate)
install.packages("keras")

# 파이썬 버전이 3.8X인 경우

use_condaenv("my_env") 
py_install("gensim==3.8.3", pip = TRUE)
install_keras(
  method  = "conda",
  conda   = conda_path,
  envname = "my_env_38", # gensim이 설치된 여러분의 가상환경.
  version = "2.10.0"
)
import("gensim")$`__version__`

# 파이썬 버전이 3.1X인 경우

conda_create("my_env_38", packages = "python=3.8")
use_condaenv("my_env_38")
conda_install("my_env_38",
              packages = c("numpy<2", "scipy<1.10", "cython<3", "smart_open<6", "gensim=3.8.3")
)
install_keras(
  method  = "conda",
  conda   = conda_path,
  envname = "my_env_38", # gensim이 설치된 여러분의 가상환경.
  version = "2.10.0"
)
import("gensim")$`__version__`