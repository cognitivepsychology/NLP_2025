## 2주차 퀴즈 문제 2번 답안 ##

# R 패키지 rvest 불러오기.
library(rvest)

# 신문기사 URL 문자열 R 객체에 할당하기.
url.hk <- "https://www.hankookilbo.com/News/Read/A2025090310220002905"

# 해당 URL 웹페이지를 읽어들이기.
h <- read_html(url.hk)

# 객체 h의 내용 확인하기.
h

# 객체 h에서 p.editor-p 노드마ㅏㄴ 추출하여 원 텍스트로 읽어들이기.
webpage.hk <- h %>%
  html_nodes("p.editor-p") %>% 
  html_text()

# 텍스트 확인하기(optional) 
cat(webpage.hk, sep ="\n") # 개행 단위로 텍스트 보기.